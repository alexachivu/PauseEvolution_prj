import os
import re

# Get list of all fastq.gz files in the current directory
fastq_files = [f for f in os.listdir('.') if f.endswith('.fastq.gz')]

# Rename files by inserting 'R' before the paired-end identifier (1 or 2)
for file in fastq_files:
    new_name = re.sub(r'_(\d)\.fastq\.gz$', r'_R\1.fastq.gz', file)
    os.rename(file, new_name)
    print(f'Renamed: {file} -> {new_name}')

